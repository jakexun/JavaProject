package data.process;

import java.util.Scanner;

public class ErFen {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int[] array=new int[n];
        for (int i=0;i<n;i++){
            array[i]=sc.nextInt();
        }
        int x=sc.nextInt();
        Erfen(array,0,n-1,1,x);
    }
    public static int Erfen(int[] array,int start,int end,int i,int x){
        int middle=(start+end)/2;
        if (x==array[middle]){
            System.out.println(middle);
            System.out.println(i);
            return i;
        }
        else if (start!=end&&x<array[middle]){
            Erfen(array,start,middle-1,i+1,x);
        }else if (start!=end&&x>array[middle]){
            Erfen(array,middle+1,end,i+1,x);
        }else if (start==end){
            System.out.println(-1);
            System.out.println(i);
            return i;
        }
        return i;
    }
}
